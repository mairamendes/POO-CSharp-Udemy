﻿using System.Globalization;

namespace AulaInterface.Services
{
    interface ITaxService
    {
        public double Tax(double amount);
    }
}
