﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExercicioFuncionario.Entities.Enums
{
    enum WorkerLevel : int
    {
        Junior = 0,
        MidLevel = 1,
        Senior = 2
    }
}
