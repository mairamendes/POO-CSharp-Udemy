﻿namespace AulaGenerics
{

}