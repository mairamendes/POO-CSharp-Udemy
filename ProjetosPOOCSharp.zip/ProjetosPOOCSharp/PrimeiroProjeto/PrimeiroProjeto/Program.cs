﻿using System;

namespace PrimeiroProjeto
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}