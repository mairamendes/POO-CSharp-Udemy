﻿

namespace AulaMetEClasAbstratos.Entities.Enums
{
    enum Color
    {
        Black, 
        Blue,
        Red
    }
}
